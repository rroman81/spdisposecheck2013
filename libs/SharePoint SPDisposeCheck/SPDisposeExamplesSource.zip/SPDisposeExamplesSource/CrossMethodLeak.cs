//--------------------------------------------------------------------------------
// This file is a "Sample" as part of the MICROSOFT SDK SAMPLES FOR SHAREPOINT
// PRODUCTS AND TECHNOLOGIES
//
// (c) 2008 Microsoft Corporation.  All rights reserved.  
//
// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//--------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using SPDisposeCheck;

// SharePoint 2007 Dispose Patterns By Example
// SharePoint Dispose Microsoft Best Practices Examples http://blogs.msdn.com/rogerla
// By Roger Lamb, Architect ADC | Microsoft Corporation

namespace SPDisposeExamples
{
    #region CrossMethodLeak
    
    public class CrossMethodLeak
    {
        private SPSite _siteCollection = null;
        private SPWeb _web = null;
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_110, "Don't want to do it")]
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_120, "Don't want to do it")]
        public void MethodA()
        {
            _siteCollection = new SPSite("http://moss");
            _web = _siteCollection.OpenWeb();
        }

        public void MethodB()
        {
            if (_web != null)
            {
                string title = _web.Title;
            }
        }

        public void MethodC()
        {
            if (_web != null)
            {
                string name = _web.Name;
            }
        }
    }

    #endregion
}
