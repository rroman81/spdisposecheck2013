//--------------------------------------------------------------------------------
// This file is a "Sample" as part of the MICROSOFT SDK SAMPLES FOR SHAREPOINT
// PRODUCTS AND TECHNOLOGIES
//
// (c) 2008 Microsoft Corporation.  All rights reserved.  
//
// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//--------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using SPDisposeCheck;

// SharePoint 2007 Dispose Patterns By Example
// SharePoint Dispose Microsoft Best Practices Examples http://blogs.msdn.com/rogerla
// By Roger Lamb, Architect ADC | Microsoft Corporation

namespace SPDisposeExamples
{
    public class SPSiteLeak
    {
        
        #region CreateSPSite

        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_110, "Don't want to do it")]
        public void CreatingSPSiteLeak()
        {
            SPSite siteCollection = new SPSite("http://moss");
            // siteCollection leaked
        }

        public void CreatingSPSiteExplicitDisposeNoLeak()
        {
            SPSite siteCollection = null;
            try
            {
                siteCollection = new SPSite("http://moss");
            }
            finally
            {
                if (siteCollection != null)
                    siteCollection.Dispose();
            }
        }

        public void CreatingSPSiteWithAutomaticDisposeNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
            } // SPSite object siteCollection.Dispose() automatically called
        }
        #endregion

        #region OpenWeb
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_110, "Don't want to do it")]
        public void OpenWebLeak()
        {
            using (SPWeb web = new SPSite(SPContext.Current.Web.Url).OpenWeb())
            {
                // SPSite leaked !
            } // SPWeb object web.Dispose() automatically called
        }

        public void OpenWebNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                } // SPWeb object web.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called
        }
        #endregion

        #region AllWebs
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_130, "Don't want to do it")]
        public void AllWebsForEachLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb outerWeb = siteCollection.OpenWeb())
                {
                    foreach (SPWeb innerWeb in siteCollection.AllWebs)
                    {
                        // explicit dispose here to avoid OOM's with large # of webs
                    }
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        public void AllWebsForEachNoLeakOrMemoryOOM()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb outerWeb = siteCollection.OpenWeb())
                {
                    foreach (SPWeb innerWeb in siteCollection.AllWebs)
                    {
                        try
                        {
                            // ...
                        }
                        finally
                        {
                            if(innerWeb != null)
                                innerWeb.Dispose();
                        }
                    }
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_130, "Don't want to do it")]
        public void AllWebsIndexerLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                SPWeb web = siteCollection.AllWebs[0];
                // SPWeb web leaked
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        public void AllWebsIndexerNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.AllWebs[0])
                {
                } // SPWeb object web.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        #endregion

        #region AllWebsAdd
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_150, "Don't want to do it")]
        
        public void AllWebsAddLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                SPWeb web = siteCollection.AllWebs.Add("site-relative URL");
                // SPWeb web Leaked
                //leaded again, but this time we don't even capture it in a variable
                siteCollection.AllWebs.Add("another-site-relative URL");

            }  // SPSite object siteCollection.Dispose() automatically called 

        }

        public void AllWebsAddNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.AllWebs.Add("site-relative URL"))
                {
                } // SPWeb object web.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }
        #endregion

    }
}
