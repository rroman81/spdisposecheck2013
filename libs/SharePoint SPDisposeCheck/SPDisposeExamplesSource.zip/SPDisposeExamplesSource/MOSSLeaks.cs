//--------------------------------------------------------------------------------
// This file is a "Sample" as part of the MICROSOFT SDK SAMPLES FOR SHAREPOINT
// PRODUCTS AND TECHNOLOGIES
//
// (c) 2008 Microsoft Corporation.  All rights reserved.  
//
// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//--------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;
using Microsoft.Office.Server;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint.Portal.SiteData;
using Microsoft.SharePoint.Portal;
using SPDisposeCheck;

// SharePoint 2007 Dispose Patterns By Example
// SharePoint Dispose Microsoft Best Practices Examples http://blogs.msdn.com/rogerla
// By Roger Lamb, Architect ADC | Microsoft Corporation

namespace SPDisposeExamples
{
    public class MOSSLeaks
    {

        #region PublishingWeb
        [SPDisposeCheckIgnore(SPDisposeCheckID.SPDisposeCheckID_999, "Don't want to do it")]
        
        public void PublishingWebCollectionLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    // passing in web you own, no dispose needed on outerPubWeb
                    PublishingWeb outerPubWeb = PublishingWeb.GetPublishingWeb(web);

                    PublishingWebCollection pubWebCollection = outerPubWeb.GetPublishingWebs();
                    foreach (PublishingWeb innerPubWeb in pubWebCollection)
                    {
                        // innerPubWeb leak
                    }
                    // PublishingWeb will leak for each innerPubWeb referenced
                } // SPWeb object web.Dispose() automatically called
            } // SPSite object siteCollection.Dispose() automatically called

            SPSite siteCollection2 = new SPSite("http://moss");

            SPWeb web2 = siteCollection2.OpenWeb();
                
            // passing in web you own, no dispose needed on outerPubWeb
            PublishingWeb outerPubWeb2 = PublishingWeb.GetPublishingWeb(web2);

            PublishingWebCollection pubWebCollection2 = outerPubWeb2.GetPublishingWebs();
            foreach (PublishingWeb innerPubWeb2 in pubWebCollection2)
            {
                // innerPubWeb leak
            }
            // PublishingWeb will leak for each innerPubWeb referenced
    
        }

        public void PublishingWebCollectionNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    // passing in web you own, no dispose needed on outerPubWeb
                    PublishingWeb outerPubWeb = PublishingWeb.GetPublishingWeb(web);
                    PublishingWebCollection pubWebCollection = outerPubWeb.GetPublishingWebs();
                    foreach (PublishingWeb innerPubWeb in pubWebCollection)
                    {
                        try
                        {
                            // ...
                        }
                        finally
                        {
                            if(innerPubWeb != null)
                                innerPubWeb.Close();
                        }
                    }
                    outerPubWeb.Close();
                }  // SPWeb object web.Dispose() automatically called
            } // SPSite object siteCollection.Dispose() automatically called
        }

        public void GetPublishingWebNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    // passing in web you own, no dispose needed on singlePubWeb
                    PublishingWeb singlePubWeb = PublishingWeb.GetPublishingWeb(web);
                } // SPWeb object web.Dispose() automatically called
            } // SPSite object siteCollection.Dispose() automatically called
        }
        #endregion

        #region BreakRoleInheritance
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_100, "Don't want to do it")]
        
        public void SPListBreakRoleInheritanceLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    SPList list = web.Lists["ListName"];
                    list.BreakRoleInheritance(true);
                    // SPWeb list.ParentWeb leaked here, requires call to list.ParentWeb.Dispose()
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        public void SPListBreakRoleInheritanceNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    SPList list = null;
                    try
                    {
                        list = web.Lists["ListName"];
                        list.BreakRoleInheritance(true);
                    }
                    finally
                    {
                        if (list != null)
                            list.ParentWeb.Dispose(); // Best practice 
                    }
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        #endregion

        #region PersonalSite
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_400, "Don't want to do it")]
        
        void PersonalSiteLeak()
        {
            // open a site collection
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                UserProfileManager profileManager = new UserProfileManager(ServerContext.GetContext(siteCollection));
                UserProfile profile = profileManager.GetUserProfile("domain\\username");
                SPSite personalSite = profile.PersonalSite;    // will leak
            }
        }

        void PersonalSiteNoLeak()
        {
            // open a site collection
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                UserProfileManager profileManager = new UserProfileManager(ServerContext.GetContext(siteCollection));
                UserProfile profile = profileManager.GetUserProfile("domain\\username");
                using (SPSite personalSite = profile.PersonalSite)
                {
                    // ...
                }
            }
        }

        #endregion

        #region GetVariation
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_320, "Don't want to do it")]
        
        public void GetVariationLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    PublishingWeb publishingWeb = PublishingWeb.GetPublishingWeb(web);  // Passing in web so no Close() needed
                    VariationLabel variationLabel = Variations.Current.UserAccessibleLabels[0];
                    PublishingWeb variationPublishingWeb = publishingWeb.GetVariation(variationLabel);  // must be Closed()
                    // ...
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        public void GetVariationNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    PublishingWeb variationPublishingWeb = null;
                    try
                    {
                        PublishingWeb publishingWeb = PublishingWeb.GetPublishingWeb(web);  // Passing in web so no Close() needed
                        VariationLabel variationLabel = Variations.Current.UserAccessibleLabels[0];
                        variationPublishingWeb = publishingWeb.GetVariation(variationLabel);  // must be Closed()
                        // ...
                    }
                    finally
                    {
                        if(variationPublishingWeb != null)
                            variationPublishingWeb.Close();
                    }
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        #endregion

        #region Area
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_500, "Don't want to do it")]
        
        public void AreaWebLeak()
        {
            // AreaManager and Area are obsolete in MOSS but this should still be noted
            Area area = AreaManager.GetArea(PortalContext.Current, new Guid("{GUID}"));
            string str = area.Web.Title;
            // SPWeb area.Web leak
        }

        public void AreaWebNoLeak()
        {
            Area area = null;
            try
            {
                // AreaManager and Area are obsolete in MOSS but this should still be noted
                area = AreaManager.GetArea(PortalContext.Current, new Guid("{GUID}"));
                string str = area.Web.Title;
            }
            finally
            {
                area.Web.Dispose();
            }
        }
        #endregion

    }
}
