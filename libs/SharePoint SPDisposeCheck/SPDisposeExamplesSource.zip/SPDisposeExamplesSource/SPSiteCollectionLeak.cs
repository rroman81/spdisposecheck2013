//--------------------------------------------------------------------------------
// This file is a "Sample" as part of the MICROSOFT SDK SAMPLES FOR SHAREPOINT
// PRODUCTS AND TECHNOLOGIES
//
// (c) 2008 Microsoft Corporation.  All rights reserved.  
//
// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//--------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using SPDisposeCheck;

// SharePoint 2007 Dispose Patterns By Example
// SharePoint Dispose Microsoft Best Practices Examples http://blogs.msdn.com/rogerla
// By Roger Lamb, Architect ADC | Microsoft Corporation

namespace SPDisposeExamples
{
    public class SPSiteCollectionLeak
    {
        #region SPSiteCollection.Add()
        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_240, "Don't want to do it")]
        
        public void SPSiteCollectionAddLeak()
        {
            using (SPSite siteCollectionOuter = new SPSite("http://moss"))
            {
                SPWebApplication webApp = siteCollectionOuter.WebApplication;
                SPSiteCollection siteCollections = webApp.Sites;
                SPSite siteCollectionInner = siteCollections.Add("sites/myNewSiteCollection",
                    "DOMAIN\\User", "roger.lamb@litwareinc.com");
                // SPSite siteCollectionInner leak
            }
        }

        public void SPSiteCollectionAddNoLeak()
        {
            using (SPSite siteCollectionOuter = new SPSite("http://moss"))
            {
                SPWebApplication webApp = siteCollectionOuter.WebApplication;
                SPSiteCollection siteCollections = webApp.Sites;
                using (SPSite siteCollectionInner = siteCollections.Add("sites/myNewSiteCollection",
                    "DOMAIN\\User", "roger.lamb@litwareinc.com"))
                {
                } // SPSite object siteCollectionInner.Dispose() automatically called
            } // SPSite object siteCollectionOuter.Dispose() automatically called
        }
        #endregion

        #region SPSiteCollectionIndexer

        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_230, "Don't want to do it")]
        
        public void SPSiteCollectionIndexerLeak()
        {
            using (SPSite siteCollectionOuter = new SPSite("http://moss"))
            {
                SPWebApplication webApp = siteCollectionOuter.WebApplication;
                SPSiteCollection siteCollections = webApp.Sites;

                SPSite siteCollectionInner = siteCollections[0];
                // SPSite siteCollectionInner leak 
            } // SPSite object siteCollectionOuter.Dispose() automatically called
        }

        public void SPSiteCollectionIndexerNoLeak()
        {
            using (SPSite siteCollectionOuter = new SPSite("http://moss"))
            {
                SPSite siteCollectionInner = null;
                try
                {
                    SPWebApplication webApp = siteCollectionOuter.WebApplication;
                    SPSiteCollection siteCollections = webApp.Sites;

                    siteCollectionInner = siteCollections[0];
                }
                finally
                {
                    if (siteCollectionInner != null)
                        siteCollectionInner.Dispose();
                }
            } // SPSite object siteCollectionOuter.Dispose() automatically called
        }

        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_230, "Don't want to do it")]
        
        public void SPSiteCollectionForEachLeak()
        {
            using (SPSite siteCollectionOuter = new SPSite("http://moss"))
            {
                SPWebApplication webApp = siteCollectionOuter.WebApplication;
                SPSiteCollection siteCollections = webApp.Sites;

                foreach (SPSite siteCollectionInner in siteCollections)
                {
                    // SPSite siteCollectionInner leak
                }
            } // SPSite object siteCollectionOuter.Dispose() automatically called
        }

        public void SPSiteCollectionForEachNoLeak()
        {
            using (SPSite siteCollectionOuter = new SPSite("http://moss"))
            {
                SPWebApplication webApp = siteCollectionOuter.WebApplication;
                SPSiteCollection siteCollections = webApp.Sites;

                foreach (SPSite siteCollectionInner in siteCollections)
                {
                    try
                    {
                        // ...
                    }
                    finally
                    {
                        if(siteCollectionInner != null)
                            siteCollectionInner.Dispose();
                    }
                }
            } // SPSite object siteCollectionOuter.Dispose() automatically called
        }

        #endregion
    }
}
