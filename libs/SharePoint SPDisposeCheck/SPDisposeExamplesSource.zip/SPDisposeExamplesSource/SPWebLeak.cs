//--------------------------------------------------------------------------------
// This file is a "Sample" as part of the MICROSOFT SDK SAMPLES FOR SHAREPOINT
// PRODUCTS AND TECHNOLOGIES
//
// (c) 2008 Microsoft Corporation.  All rights reserved.  
//
// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
// 
// THIS CODE AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//--------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.WebPartPages;
using SPDisposeCheck;

// SharePoint 2007 Dispose Patterns By Example
// SharePoint Dispose Microsoft Best Practices Examples http://blogs.msdn.com/rogerla
// By Roger Lamb, Architect ADC | Microsoft Corporation

namespace SPDisposeExamples
{
    public class SPWebLeak
    {
        #region GetLimitedWebPartManager

        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_160, "Don't want to do it")]
        
        public void SPLimitedWebPartManagerLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb()) 
                {
                    SPFile page = web.GetFile("Source_Folder_Name/Source_Page");
                    SPLimitedWebPartManager webPartManager = page.GetLimitedWebPartManager(PersonalizationScope.Shared);
                    // SPWeb object webPartManager.Web leaked
                } // SPWeb object web.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        public void SPLimitedWebPartManagerNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    SPFile page = web.GetFile("Source_Folder_Name/Source_Page");
                    using (SPLimitedWebPartManager webPartManager = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                    {
                        try
                        {
                            // ...
                        }
                        finally
                        {
                            webPartManager.Web.Dispose();
                        }
                    }
                } // SPWeb object web.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }
        
        #endregion

        #region Webs

        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_180, "Don't want to do it")]
        
        public void WebsLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb outerWeb = siteCollection.OpenWeb())
                {
                    foreach (SPWeb innerWeb in outerWeb.Webs)
                    {
                        // SPWeb innerWeb leak
                    }
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        public void WebsNoLeak()
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb outerWeb = siteCollection.OpenWeb())
                {
                    foreach (SPWeb innerWeb in outerWeb.Webs)
                    {
                        try //should be 1st statement after foreach
                        {
                            // ...
                        }
                        finally
                        {
                            if(innerWeb != null)
                                innerWeb.Dispose();
                        }
                    }
                } // SPWeb object outerWeb.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called 
        }

        #endregion

        #region Webs.Add()

        //[SPDisposeCheckIgnoreAttribute(SPDisposeCheckID.SPDisposeCheckID_150, "Don't want to do it")]
        
        public void WebsAddLeak(string strWebUrl)
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    SPWeb addedWeb = web.Webs.Add(strWebUrl);   // will leak

                } // SPWeb object web.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called
        }

        public void WebsAddNoLeak(string strWebUrl)
        {
            using (SPSite siteCollection = new SPSite("http://moss"))
            {
                using (SPWeb web = siteCollection.OpenWeb())
                {
                    using (SPWeb addedWeb = web.Webs.Add(strWebUrl))
                    {
                        //..
                    }

                } // SPWeb object web.Dispose() automatically called
            }  // SPSite object siteCollection.Dispose() automatically called
        }

        public void TryFinallyNoLeak()
        {
            SPSite siteCollection = null;
            SPWeb web = null;

            try
            {
                siteCollection = new SPSite("http://moss");
                web = siteCollection.OpenWeb();
                Console.WriteLine(web.Title);
            }
            // catch() optional, but make sure you process
            finally
            {
                if (web != null)
                    web.Dispose();

                if (siteCollection != null)
                    siteCollection.Dispose();
            }
        }

        #endregion
    }
}
